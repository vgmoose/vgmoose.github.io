Hi! These are the 3D files for the ORAS Missingno video. Also included are the original files that were used to export the model. 

These models are available to use under the CC-BY license. 
Full text: https://creativecommons.org/licenses/by/4.0/ 

TLDR: Feel free to use these models for whatever you want, but please credit me if you do! 

- VGMoose